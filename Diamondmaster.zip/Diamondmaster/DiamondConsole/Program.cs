﻿
//using Diamond.Business;

//Console.WriteLine("Enter a Character from A to Z");
//char inputChar = Console.ReadKey().KeyChar;
//Console.WriteLine("\n");


//int no = DiamondHelper.GetNumberForLetter(inputChar);
//var diamondString = DiamondHelper.BuildStringInDiamondShape(no);
//foreach (var diamond in diamondString)
//{
//    if (diamond != null)
//        Console.WriteLine(diamond);
//}
//var reverseDiamondString = DiamondHelper.ReverseString(no, diamondString);

//foreach (var diamond in reverseDiamondString)
//{
//    if (diamond != null)
//        Console.WriteLine(diamond.ToString());
//}
//Console.ReadKey();

using System;
using System.Collections.Generic;

namespace HelloWorld
{
    class Program
    {
        static List<char> braces = new List<char>();
        static void push(char x)
        {
            braces.Add(x);
        }

        static char pop()
        {
            if (braces.Count > 0)
            {
                var lastchar = braces[braces.Count - 1];
                braces.RemoveAt(braces.Count - 1);
                return lastchar;
            }
            else
                return ' ';
        }
        static void Main(string[] args)
        {
            string questionString = "[{( a - b)";
            bool result = false;


            foreach (char bracket in questionString.ToCharArray())
            {
                if (bracket == '[' || bracket == '{' || bracket == '(' )
                {
                    push(bracket);
                    continue;
                }
                else if(bracket != ']' && bracket != '}' && bracket != ')')
                {
                    continue;
                }

                if (bracket == ']')
                {
                    if (pop() == '[')
                        result = true;
                    else
                        break;
                }

                if (bracket == '}')
                {
                    if (pop() == '{')
                        result = true;
                    else
                        break;
                }

                if (bracket == ')')
                {
                    if (pop() == '(')
                        result = true;
                    else
                        break;
                }
            }

            if (braces.Count > 0)
                result = false;
            

            //var length = (int)Math.Floor((double)braces.Count / 2);



            //for (int i = 0; i < length; i++)
            //{
            //    Console.WriteLine(braces[i]);
            //    Console.WriteLine(braces[braces.Count - 1 - i]);

            //    if (braces[i] == '[')
            //    {
            //        if (braces[braces.Count - 1 - i] == ']')
            //            result = true;
            //        else
            //            result = false;
            //    }

            //    if (braces[i] == '{')
            //    {
            //        if (braces[braces.Count - 1 - i] == '}')
            //            result = true;
            //        else
            //            result = false;
            //    }

            //    if (braces[i] == '(')
            //    {
            //        if (braces[braces.Count - 1 - i] == ')')
            //            result = true;
            //        else
            //            result = false;
            //    }
            //}

            Console.WriteLine(result);
        }
    }
}