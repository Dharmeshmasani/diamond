﻿
using Diamond.Business;

Console.WriteLine("Enter a Character from A to Z");
char inputChar = Console.ReadKey().KeyChar;
Console.WriteLine("\n");

if (DiamondHelper.GetLetters().Contains(char.ToUpper(inputChar)))
{

    int no = DiamondHelper.GetNumberForLetter(inputChar);
    var diamondString = DiamondHelper.BuildStringInDiamondShape(no);
    foreach (var diamond in diamondString)
    {
        if (diamond != null)
            Console.WriteLine(diamond);
    }
}
else
{
    Console.WriteLine("Please input valid Character.");
}

Console.ReadKey();
