using Xunit;
using Diamond.Business;

namespace Diamond.Tests
{
    public class DiamondTest
    {
        [Fact]
        public void Test_LetterList_Incorrect()
        {
            // Arrange
            var letters = new char[26];
            
            //Act
            var letterList = DiamondHelper.GetLetters();

            //Assert
            Assert.NotEqual(letters, letterList);
        }

        [Fact]
        public void Test_LetterList()
        {
            // Arrange
            var letters = new char[]
            {
                 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'
            };

            //Act
            var letterList = DiamondHelper.GetLetters();
            
            //Assert
            Assert.Equal(letters, letterList);
        }

        [Fact]
        public void Test_LetterNumber_Correct()
        {
            //Arrange 
            var inputChar = 'E';
            var actualLetterNo = "4";
            string no = DiamondHelper.GetNumberForLetter(inputChar).ToString(); 
            
            //Assert
            Assert.Equal(no, actualLetterNo);
        }

        [Fact]
        public void Test_IF_DiamondString_Incorrect()
        {
            //Arrange 
            var inputChar = 'D';
            string[] diamondStr = new []{
                "A",
                "BB"
            };

            ////Act 
            int no = DiamondHelper.GetNumberForLetter(inputChar);
            var diamondString = DiamondHelper.BuildStringInDiamondShape(no);

            ////Assert
            Assert.NotEqual(diamondStr, diamondString);
        }

        [Fact]
        public void Test_IF_Diamond_Is_Correct()
        {
            //Arrange 
            var inputChar = 'D';
            List<string> diamondStr = new()
            {
                "   A",
                "  B B",
                " C   C",
                "D     D",
                " C   C",
                "  B B",
                 "   A"
            };

            ////Act 
            int no = DiamondHelper.GetNumberForLetter(inputChar);
            var diamondString = DiamondHelper.BuildStringInDiamondShape(no);
           
            ////Assert
            Assert.Equal(diamondStr, diamondString);
            Assert.Equal((no * 2) + 1, diamondString?.Count); //Check number of elements in string list.
            Assert.NotEqual(0, diamondString?.Count % 2); // Check odd number of rows are  there
            Assert.Equal(no + 1, diamondString?.FirstOrDefault()?.Length); // check string lenght of first item in list
        }

        [Fact]
        public void Test_IF_String_Is_InCorrect()
        {
            //Arrange 
            var inputChar = 'D';
            List<string> diamondStr = new(){
                "   A",
                "  B B",
                " C   C",
                " C   C",
                "  B B",
                 "   A"
            };

            ////Act 
            int no = DiamondHelper.GetNumberForLetter(inputChar);
            var diamondString = DiamondHelper.BuildStringInDiamondShape(no);
           
            ////Assert
            Assert.NotEqual(diamondStr, diamondString);
        }

        [Fact]
        public void Test_Invalid_Input()
        {
            //Arrange 
            var inputChar = '1';

            ////Act 
            int no = DiamondHelper.GetNumberForLetter(inputChar);
            var diamondString = DiamondHelper.BuildStringInDiamondShape(no);

            ////Assert
            Assert.Empty(diamondString);
        }

    }
}