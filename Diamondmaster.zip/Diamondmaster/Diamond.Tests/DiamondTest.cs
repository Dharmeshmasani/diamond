using Xunit;
using Diamond.Business;

namespace Diamond.Tests
{
    public class DiamondTest
    {
        [Fact]
        public void Test_LetterList_Incorrect()
        {
            // Arrange
            var letters = new char[26];
            
            //Act
            var letterList = DiamondHelper.GetLetters();

            //Assert
            Assert.NotEqual(letters, letterList);
        }

        [Fact]
        public void Test_LetterList()
        {
            // Arrange
            var letters = new char[]
            {
                 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'
            };

            //Act
            var letterList = DiamondHelper.GetLetters();
            
            //Assert
            Assert.Equal(letters, letterList);
        }

        [Fact]
        public void Test_LetterNumber_Correct()
        {
            //Arrange 
            var inputChar = 'E';
            var actualLetterNo = "4";
            string no = DiamondHelper.GetNumberForLetter(inputChar).ToString(); 
            
            //Assert
            Assert.Equal(no, actualLetterNo);
        }

        [Fact]
        public void Test_DiamondString_Equal()
        {
            //Arrange 
            var inputChar = 'D';
            string[] diamondStr = new []{
                "   A",
                "  B B",
                " C   C",
                "D     D"
            };

            ////Act 
            int no = DiamondHelper.GetNumberForLetter(inputChar);
            var diamondString = DiamondHelper.BuildStringInDiamondShape(no);

            ////Assert
            Assert.Equal(diamondStr, diamondString);
        }
      
        [Fact]
        public void Test_IF_DiamondString_Incorrect()
        {
            //Arrange 
            var inputChar = 'D';
            string[] diamondStr = new []{
                "A",
                "BB"
            };

            ////Act 
            int no = DiamondHelper.GetNumberForLetter(inputChar);
            var diamondString = DiamondHelper.BuildStringInDiamondShape(no);

            ////Assert
            Assert.NotEqual(diamondStr, diamondString);
        }

        [Fact]
        public void Test_ReverseDiamondString_Correct()
        {
            //Arrange 
            var inputChar = 'C';
            string[] reverseDiamondStr = new []{
                " B B",
                "  A"
            };

            ////Act 
            int no = DiamondHelper.GetNumberForLetter(inputChar);
            var diamondString = DiamondHelper.BuildStringInDiamondShape(no);

            var reverseDiamondString = DiamondHelper.ReverseString(no, diamondString);

            ////Assert
            Assert.Equal(reverseDiamondStr, reverseDiamondString);
        }
        [Fact]
        public void Test_ReverseString_Is_NotEqual()
        {
            //Arrange 
            var inputChar = 'D';
            string[] reverseDiamondStr = new[] {
                " B B",
                "  A"
            };

            ////Act 
            int no = DiamondHelper.GetNumberForLetter(inputChar);
            var diamondString = DiamondHelper.BuildStringInDiamondShape(no);
            var reverseDiamondString = DiamondHelper.ReverseString(no, diamondString);

            ////Assert
            Assert.NotEqual(reverseDiamondStr, reverseDiamondString);
        }

        [Fact]
        public void Test_IF_Diamond_Is_Correct()
        {
            //Arrange 
            var inputChar = 'D';
            string[] diamondStr = new[]{
                "   A",
                "  B B",
                " C   C",
                "D     D",
                " C   C",
                "  B B",
                 "   A"
            };

            ////Act 
            int no = DiamondHelper.GetNumberForLetter(inputChar);
            var diamondString = DiamondHelper.BuildStringInDiamondShape(no).ToList();
            var reverseString = DiamondHelper.ReverseString(no, diamondString.ToArray());
            diamondString.AddRange(reverseString);
            ////Assert
            Assert.Equal(diamondStr, diamondString.ToArray());
        }

        [Fact]
        public void Test_IF_String_Is_InCorrect()
        {
            //Arrange 
            var inputChar = 'D';
            string[] diamondStr = new[]{
                "   A",
                "  B B",
                " C   C",
                " C   C",
                "  B B",
                 "   A"
            };

            ////Act 
            int no = DiamondHelper.GetNumberForLetter(inputChar);
            var diamondString = DiamondHelper.BuildStringInDiamondShape(no).ToList();
            var reverseString = DiamondHelper.ReverseString(no, diamondString.ToArray());
            diamondString.AddRange(reverseString);
           
            ////Assert
            Assert.NotEqual(diamondStr, diamondString.ToArray());
        }

    }
}