using Xunit;
using Diamond.Business;

namespace Diamond.Tests
{
    public class DiamondTest
    {
        string strLatters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        //Test and verify diamond shape, length, rows and columns Horizonat & varical symmetry  of return value.
        [Fact]
        public void Test_IF_Diamond_Is_Correct()
        {
            //Arrange 
            var inputChar = 'D';

            ////Act 
            int no = DiamondHelper.GetIndexOfLatter(inputChar);
            var diamondString = DiamondHelper.BuildStringInDiamondShape(no);

            ////Assert
            Assert.Equal((no * 2) + 1, diamondString?.Count); //Check number of elements in string list.
            Assert.NotEqual(0, diamondString?.Count % 2); // Check odd number of rows are  there
            Assert.Equal(no + 1, diamondString?.FirstOrDefault()?.Length); // check string length of first item in list
            Assert.Equal(no + 1, diamondString?.LastOrDefault()?.Length);// check string length of last item in list
            Assert.Equal(diamondString?.FirstOrDefault()?.Length, diamondString?.LastOrDefault()?.Length); // length of first and last row should be same.
        }

        //Test Invalid diamond shape return value from function.
        [Fact]
        public void Test_IF_String_Is_InCorrect()
        {
            //Arrange 
            var inputChar = 'D';

            ////Act 
            int no = DiamondHelper.GetIndexOfLatter(inputChar);
            var diamondString = DiamondHelper.BuildStringInDiamondShape(no);
            var lineString = BuildStringInLineShape(inputChar);
           
            ////Assert
            Assert.NotEqual(lineString, diamondString); //Check if its not in anyother shape.
            Assert.NotEqual(lineString.Count, diamondString?.Count); //Check number of elements in string list.
            Assert.Equal(1, diamondString?.Count % 2); // Check even number of rows are  there
            Assert.NotEqual(lineString?.FirstOrDefault()?.Length, diamondString?.LastOrDefault()?.Length); //check if length of first and last row is not same.
        }

        //Test Invalid return value from function.
        [Fact]
        public void Test_IF_String_Is_Diamond()
        {
            //Arrange 
            var inputChar = 'D';

            ////Act 
            int no = DiamondHelper.GetIndexOfLatter(inputChar);
            var diamondString = DiamondHelper.BuildStringInDiamondShape(no);
            var lineString = BuildStringInLineShape(inputChar);

            ////Assert
            Assert.NotEqual(lineString, diamondString); //Check if its not in anyother shape.
            Assert.Equal((no * 2) + 1, diamondString?.Count); //Check number of elements in string list.
            Assert.NotEqual(0, diamondString?.Count % 2); // Check even number of rows are  there
            Assert.Equal(diamondString?.FirstOrDefault()?.Length, diamondString?.LastOrDefault()?.Length); //check if length of first and last row is not same.
        }


        //Test length of latters array.
        [Fact]
        public void Test_LetterList_Incorrect()
        {
            // Arrange
            var letters = new char[26];

            //Act
            var letterList = DiamondHelper.Letters;

            //Assert
            Assert.NotEqual(letters, letterList);
        }

        //Testing list of latters.
        [Fact]
        public void Test_LetterList()
        {
            // Arrange
            var letters = strLatters.ToCharArray();

            //Act
            var letterList = DiamondHelper.Letters;

            //Assert
            Assert.Equal(letters, letterList);
        }

        //Check index number of particular input latter.
        [Fact]
        public void Test_LetterNumber_Correct()
        {
            //Arrange 
            var inputChar = 'E';
            var actualLetterNo = "4";
            string no = DiamondHelper.GetIndexOfLatter(inputChar).ToString();

            //Assert
            Assert.Equal(no, actualLetterNo);
        }

        //Test incorrect shape diamond.
        [Fact]
        public void Test_IF_DiamondString_Incorrect()
        {
            //Arrange 
            var inputChar = 'D';
            string[] diamondStr = new[]{
                "A",
                "BB"
            };

            ////Act 
            int no = DiamondHelper.GetIndexOfLatter(inputChar);
            var diamondString = DiamondHelper.BuildStringInDiamondShape(no);

            ////Assert
            Assert.NotEqual(diamondStr, diamondString);
        }

        //Test invalid input value.
        [Fact]
        public void Test_Invalid_Input()
        {
            //Arrange 
            var inputChar = '1';

            ////Act 
            int no = DiamondHelper.GetIndexOfLatter(inputChar);
            var diamondString = DiamondHelper.BuildStringInDiamondShape(no);

            ////Assert
            Assert.Empty(diamondString);
        }


        private List<string> BuildStringInLineShape(char input)
        {
            return (strLatters.IndexOf(input)) > 0 ? new List<string> { strLatters.Substring(0, strLatters.IndexOf(input) - 1) } : new List<string> { "" };
        }
    }
}
