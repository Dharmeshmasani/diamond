﻿namespace Diamond.Business
{
    public static class DiamondHelper
    {
        public static char[] Letters = new char[26]{
                'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'
            };
           
        public static int GetNumberForLetter(char inputLetter)
        {
            int no = 0;
            int counter = 0; 

            foreach(var letter in Letters)
            {
                if(letter == Convert.ToChar(char.ToUpper(inputLetter)))
                {
                    no = counter;
                    break;
                }
                counter++;
            }

            return no;
        }

        public static List<string> BuildStringInDiamondShape(int no)
        {
            var letters = DiamondHelper.Letters;
            var returnValue = new List<string>();
            var diamond = new string[52];

            if (no == 0)
                return returnValue;

            for (int i = 0; i <= no; i++)
            {
                for (int j = 0; j < no - i; j++)
                {
                    diamond[i] += " ";
                }

                diamond[i] += letters[i];

                //add space between letters
                if (letters[i] != 'A')
                {
                    for (int j = 0; j < 2 * i - 1; j++)
                    {
                        diamond[i] += " ";
                    }
                    diamond[i] += letters[i];
                }
                returnValue.Add(diamond[i]);
            }

            var reverseString = ReverseString(no, returnValue);
            returnValue.AddRange(reverseString);

            return returnValue;
        }
        private static List<string> ReverseString(int letterNo, List<string> diamondArray)
        {
            var reverse = new List<string>();
            for (int i = letterNo - 1; i >= 0; i--)
            {
                reverse.Add(diamondArray[i]);
            }
            return reverse;
        }

    }
}